const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

const getStorage = storageKey => {
  try {
    var sessionId = wx.getStorageSync(storageKey)
    return sessionId;
  } catch (e) {
    console.log(e)
  }
}

const setStorage = (key, value) => {
  try {
    wx.setStorageSync(key, value)
  } catch (e) {
    console.log(e)
  }
}

module.exports = {
  formatTime: formatTime,
  getStorage: getStorage,
  setStorage: setStorage,
}
