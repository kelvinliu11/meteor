// 首页加载完之后，在storage中有：
// sessionId: 与服务器交互的sessionId
// shops: 用户所在的shops数组
import util from './../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    indexmenu: [],
    imgUrls: [],
    indicatorDots: true,
    autoplay: true,
    interval: 4000,
    duration: 1000,
    hasShop: false,

  },

  fetchData: function () {
    this.setData({
      indexmenu: [{
          'icon': './../../images/入库管理.png',
          'text': '入库管理',
          'url': 'checkin'
        },
        {
          'icon': './../../images/出库管理.png',
          'text': '出库管理',
          'url': 'checkout'
        },
        {
          'icon': './../../images/创建商品.png',
          'text': '创建商品',
          'url': 'goodscategory'
        },
        {
          'icon': './../../images/修改商品.png',
          'text': '修改商品',
          'url': 'goodsinfochange'
        },
        {
          'icon': './../../images/库存盘点.png',
          'text': '库存盘点',
          'url': 'inventorycheck'
        },
        {
          'icon': './../../images/店员管理.png',
          'text': '店员管理',
          'url': 'employeemanagement'
        },

      ],
      imgUrls: [
        '../../images/我的微信.jpg',
        '../../images/我的微信.jpg',
        '../../images/我的微信.jpg',
      ]
    })
  },

  changeRoute: function (e) {
    var userShopsNumber = this.checkWhetherHasShops()
    console.log(e)
    if (userShopsNumber == 0) {
      return;
    }
    var url = e.currentTarget.dataset.url

    if (url == "employeemanagement") {
      wx.showToast({
        title: '敬请期待',
        icon: 'success',
        duration: 2000
      })
      return;
    }

    wx.navigateTo({
      url: `../${url}/${url}`
    })
  },

  // 1. 根据微信用户的code，提交给服务端
  // 2. 服务端通过code换取openid并存储用户
  // 3. 服务端返回本次会话的sessionId
  // 4. 将sessionId存储在storage中，这样其他页面也可以使用这个sessionId来标识用户了
  getSessionIdByCode: function () {
    // login是静默行为，没有弹窗
    var that = this;
    wx.login({
      success(res) {
        if (res.code) {
          // 调用后台的根据code获取sessionId接口拿到sessionId并存储在小程序本地缓存
          var sessionId = that.getSessionIdByCodeThroughServer(res.code);
          console.log("获取到的sessionId是" + sessionId);
          util.setStorage('sessionId', sessionId)
          // 检查用户是否加入了店铺，如果没有，给model提示
          that.checkWhetherHasShops();
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },

  getSessionIdByCodeThroughServer(wxCode) {
    // TODO 根据微信用户code，从server换取sessionId
    return 'sessionIdForTestShouldFetchFromServer3';
  },

  // 根据storage中的sessionId查询用户是否加入了店铺，把数据存储在storage：shops变量中
  queryUserShops: function () {
    var sessionId = util.getStorage('sessionId');
    // console.log("在queryUserShops方法中获取到的sessionId是" + sessionId)
    // TODO 根据sessionId查询用户加入的店铺；下面的是mock数据
    var shops = [{
        "shopId": 1,
        "shopName": "演示店铺"
      },
      {
        "shopId": 2,
        "shopName": "我的店铺"
      }
    ];
    // var shops = [];
    util.setStorage("shops",  shops);
    return shops;
  },


  // 检查用户是否加入了店铺，如果没有，给modal提示
  // 返回用户店铺的数量
  checkWhetherHasShops () {
    var shops = this.queryUserShops();
    if (shops.length == 0) {
      wx.showModal({
        title: '提示',
        content: '请先从“我的” -> “加入店铺” 申请加入店铺后再执行操作',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
    return shops.length;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getSessionIdByCode();
    this.fetchData();
  },


})