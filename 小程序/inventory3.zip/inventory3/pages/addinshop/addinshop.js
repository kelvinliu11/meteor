// pages/addinshop/addinshop.js
import util from './../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shopInfo: null,
  },

  searchShop:function(e){
    const that = this;
    var shopName = e.detail.value.shopName
    console.log("要查找的店铺名称是" + shopName)
    // TODO 根据shopName调接口查对应的店铺信息
    var shopInfo = {
      "shopId": 1,
      "shopName": "演示店铺"
    }
    this.setData({
      shopInfo: shopInfo
    })
  },

  addinShop: function() {
    var shopInfo = this.data.shopInfo
    console.log(shopInfo)
    var sessionId = util.getStorage('sessionId')
    console.log("加入店铺addinShop获取到的sessionId是" + sessionId)
    // TODO 调用加入店铺接口
    var addInShopCallResult = {
      "success": true,
      "msg": "成功",
      "data": {}
    }
    if (addInShopCallResult.success == true) {
      wx.showModal({
        title: '提示',
        content: '加入店铺的申请信息已发出，请等待掌柜审核~',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateBack({
              delta: 1
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})