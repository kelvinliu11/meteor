import util from './../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodsProperties: [],
    showSearchPanel: true,  // 是否展示搜索面板
    searchResultList: [], // 搜索结果
    searchGoodsCondition: {},

    goodsCategory: '',
    goodsBrand: '',
    goodsModel: '',
    goodsProperties: [],
    selectedCondition: [], // 这里存放的是用户已经选择了的查询条件，key例如：goodsCategory、goodsBrand、goodsModel、property10（数字是propertyId）
    stockRemain: -1,
    checkinAmount: null,
    checkinTotalPrice: null,
    comment: null,
  },

  tapQueryText: function() {
    var showSearchPanel = this.data.showSearchPanel;
    this.setData({
      showSearchPanel: !showSearchPanel
    })
  },

  // 入库提交的时候，要检查商品分类、品牌、款号、规格、入库数量、入库总价、入库备注是否都填了，特别要注意的是规格属性要全部都选，否则不能定位到商品
  querySubmit: function (e) {
    console.log(e.detail.value)
    var pageValues = e.detail.value;
    var sessionId = util.getStorage('sessionId')
    // 对既有data数据做非空检查和参数调整（属性相关），形成入参
    var tipInfo = this.checkInput()
    if (tipInfo != null) return;
    var requestData = this.makeRequestData(e.detail.value);

    // TODO 调用入库管理接口
    var querySubmitResult = {
      "success": true,
      "msg": "成功",
      "data": [
        {
          "goodsCategory": "手机",
          "goodsBrand": "苹果",
          "goodsModel": "iPhoneXS MAX",
          "goodsDesc": "这是苹果的一款手机",
          "goodsProperties": [
            {
              "id": 1,
              "perpertyValue": "64"
            },
            {
              "id": 2,
              "perpertyValue": "6.5"
            },
            {
              "id": 3,
              "perpertyValue": "星空灰"
            }
          ],
          "goodsStock":"1",
          "goodsStockTotalPrice":10000,
          "highestPrice":10000,
          "lowestPrice":10000,
          "averagePrice":10000
        }
      ]
    }
    if (querySubmitResult.success == true) {
      this.setData({
        searchResultList: querySubmitResult.data
      })
      wx.showToast({
        title: '查询成功',
        icon: 'success',
        duration: 2000
      })   
    }
  },

  // 检查是否有属性没有填写，如果有的话，就弹出提醒
  checkInput(pageValues) {
    var tipInfo = null;
    if ( this.data.goodsCategory == '') {
      tipInfo = "商品分类不能为空";
    }
    else if ( this.data.goodsBrand == '') {
      tipInfo = "品牌不能为空";
    }
    
    if (tipInfo != null) {
      wx.showModal({
        title: '提示',
        content: tipInfo,
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return tipInfo;
    }
  },

  makeRequestData() {
    var requestData = {};
    requestData['goodsCategory'] = this.data.goodsCategory;
    requestData['goodsBrand'] = this.data.goodsBrand;
    requestData['goodsModel'] = this.data.goodsModel;
    var goodsPropertyData = [];
    var goodsProperties = this.data.goodsProperties;
    for (var i = 0; i < goodsProperties.length; i++) {
      var propertyItem = {};
      propertyItem['id'] = goodsProperties[i].id;
      propertyItem['propertyDesc'] = goodsProperties[i].propertyDesc;
      propertyItem['propertyValue'] = goodsProperties[i].propertyValue == undefined? '' : goodsProperties[i].propertyValue;
      goodsPropertyData.push(propertyItem);
    }
    requestData['goodsPropertyData'] = goodsPropertyData;
    console.log("组装好的待提交参数是")
    console.log(requestData)
  },

  // 1. 校验页面是否输入了商品分类
  // 2. 根据页面选择的商品分类查询对应的品牌
  // 3. 将品牌列表带到choose页面做选择
  chooseGoodsBrand: function () {
    console.log("获取到的goodsCategory是" + this.data.goodsCategory)
    if (this.data.goodsCategory == '') {
      wx.showModal({
        title: '提示',
        content: '请先选择商品分类或品牌！',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return;
    }
    // TODO 根据商品分类和品牌调用查询货品款号列表
    var goodsBrand = ["苹果", "华为", "小米"];
    wx.navigateTo({
      url: `../choose/choose?chooseCategory=goodsBrand&goodsBrand=` + goodsBrand.join(",")
    })
  },

  // 1. 校验页面是否输入了商品分类和品牌
  // 2. 根据页面选择的商品分类和品牌查询对应的货品款号
  // 3. 将货品款号列表带到choose页面做选择
  chooseGoodsModel: function () {
    console.log("获取到的goodsCategory是" + this.data.goodsCategory)
    console.log("获取到的goodsBrand是" + this.data.goodsBrand)
    if (this.data.goodsCategory == '' || this.data.goodsBrand == '') {
      wx.showModal({
        title: '提示',
        content: '请先选择商品分类或品牌！',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            // wx.navigateBack({
            //   delta: 1
            // })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return;
    }
    // TODO 根据商品分类和品牌调用查询货品款号列表
    var goodsModels = ["iPhoneXS MAX", "iPhoneXS", "iPhone6S Plus"];
    wx.navigateTo({
      url: `../choose/choose?chooseCategory=goodsModel&goodsModels=` + goodsModels.join(",")
    })
  },

  chooseProperty: function (e) {
    var propertyId = e.currentTarget.dataset.propertyid;
    // TODO perpertyId查询这个id下的所有数值，即对应goods_property_data表数据
    var goodsPropertyDataResult = {
      "success": true,
      "msg": "成功",
      "data": [{
          "id": 1,
          "goodsId": 1,
          "goodsModel": "iPhoneXS MAX",
          "propertyId": 1,
          "propertyDesc": "存储",
          "perpertyValue": "64",
          "propertyUnit": "G"
        },
        {
          "id": 2,
          "goodsId": 2,
          "goodsModel": "iPhoneXS",
          "propertyId": 1,
          "propertyDesc": "存储",
          "perpertyValue": "128",
          "propertyUnit": "G"
        }
      ]
    };
    var goodsPropertyData = [];
    for (var i = 0; i < goodsPropertyDataResult.data.length; i++) {
      goodsPropertyData.push(goodsPropertyDataResult.data[i].perpertyValue + goodsPropertyDataResult.data[i].propertyUnit)
    }
    wx.navigateTo({
      url: `../choose/choose?chooseCategory=goodsProperty&propertyId=` + propertyId + `&goodsPropertyData=` + JSON.stringify(goodsPropertyData)
    })
  },

  queryGoodsProperties: function (goodsCategory, goodsBrand, goodsModel) {
    // 这个方法应该在选择了商品分类和品牌后调用，这里为了测试，就在onLoad里面调用了，后续调整
    // TODO 根据商品分类、品牌、货品款号，查找对应的规格属性；如果data中的goodsProperties长度不为0，证明已经查询过了，就不用再查了
    if (this.data.goodsProperties.length == 0) {
      var goodsProperties = [{
        "id": 10,
        "propertyDesc": "内存"
      }, {
        "id": 12,
        "propertyDesc": "屏幕尺寸"
      }, {
        "id": 13,
        "propertyDesc": "颜色"
      }];
      this.setData({
        goodsProperties: goodsProperties
      })
    }
  },

  resetForm: function() {
    this.setData({
      searchGoodsCondition: {},

      goodsCategory: '',
      goodsBrand: '',
      goodsModel: '',
      goodsProperties: [],
      selectedCondition: [], // 这里存放的是用户已经选择了的查询条件，key例如：goodsCategory、goodsBrand、goodsModel、property10（数字是propertyId）
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 判断用户是否已经选择了商品分类、品牌和货品款号，如果已经选择了，那么调用规格属性的查询接口。
    this.queryGoodsProperties("手机", "苹果", "iPhoneXS MAX");



    // 
    console.log("这里可以获取到第二个页面选择的数据");
    console.log(this.data)

    var selectedCondition = this.data.selectedCondition;
    if (this.data.choosedCategory == 'goodsCategory') {
      selectedCondition['goodsCategory'] = this.data.choosedData
      this.setData({
        goodsCategory: this.data.choosedData,
        selectedCondition: selectedCondition,
      })
    }
    if (this.data.choosedCategory == 'goodsBrand') {
      selectedCondition['goodsBrand'] = this.data.choosedData
      this.setData({
        goodsBrand: this.data.choosedData,
        selectedCondition: selectedCondition,
      })
    }
    if (this.data.choosedCategory == 'goodsModel') {
      selectedCondition['goodsModel'] = this.data.choosedData
      this.setData({
        goodsModel: this.data.choosedData,
        selectedCondition: selectedCondition,
      })
    }
    if (this.data.choosedCategory == 'goodsProperty') {
      var goodsProperties = this.data.goodsProperties;
      for (var i = 0; i < goodsProperties.length; i++) {
        if (goodsProperties[i].id == this.data.choosedPropertyId) {
          goodsProperties[i]['propertyValue'] = this.data.choosedData;
          var selectedPropertyKey = 'property' + this.data.choosedPropertyId
          selectedCondition[selectedPropertyKey] = this.data.choosedData
        }
      }
      this.setData({
        goodsProperties: goodsProperties,
        selectedCondition: selectedCondition,
      })
    }

    // TODO 只要用户选择了商品分类和品牌，那么其他条件，比如货品款号、规格属性中任意一个变化，那么就调用后台接口查询当前库存（先做成每次都根据selectedCondition调用查询库存接口）
    var stockRemain = 99;
    this.setData({
      stockRemain: stockRemain
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})