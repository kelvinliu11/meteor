// pages/choose/choose.js
// 调用的页面，通过这几个字段取值（会设置在调用页面的data域中）
// choosedCategory: 类别
// choosedIndex: 选取的index
// choosedData: 选取的数据值
Page({

  /**
   * 页面的初始数据
   */
  data: {
    chooseCategory: null,
    categoryData: [],
    optionsData: null
  },

  fetchData: function (chooseCategory) {
    // 这里要根据chooseCategory来调用后台服务获取可选的列表信息
    console.log("需要获取的列表信息项是：" + chooseCategory)

    var serverDataList = [];
    if (chooseCategory == "goodsCategory") {
      serverDataList = ["手机", "移动互联网", "手机游戏", "互联网金融", "O2O", "智能硬件", "SNS社交", "旅游", "影视剧", "生活服务", "电子商务", "教育培训", "运动和健康", "休闲娱乐", "现代农业", "文化创意", "节能环保", "新能源", "生物医药", "IT软件", "硬件", "其他"]
    }else if (chooseCategory == "goodsBrand") {
      serverDataList = this.data.optionsData.goodsBrand.split(",")
    }else if (chooseCategory == "checkoutType") {
      serverDataList = ["销售开单", "移库", "其他"]
    }else if (chooseCategory == "goodsModel") {
      serverDataList = this.data.optionsData.goodsModels.split(",")
    }else if (chooseCategory == "goodsProperty") {
      console.log(this.data.optionsData.goodsPropertyData)
      serverDataList = JSON.parse( this.data.optionsData.goodsPropertyData )
    }

    this.setData({
      categoryData: serverDataList,
      chooseCategory: chooseCategory,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options)
    // 将options参数设置到本页面变量中，这样就不用每个方法传参了。主要是传递的一些其他参数：
    //    如果是查商品分类，那么直接取chooseCagegory里面的值就可以了
    //    如果是查询memory，还需要关联goodsCategory和goodsBrand查询，就是多个参数了
    this.setData({optionsData: options})
    this.fetchData(options.chooseCategory)
  },

  chooseItem: function (e) {
    let that = this;
    // console.log(e.currentTarget.dataset)
    let pages = getCurrentPages(); //获取当前页面js里面的pages里的所有信息。
    let prevPage = pages[pages.length - 2];
    prevPage.setData({
      // 设置需要传递的参数
      choosedCategory: that.data.chooseCategory,
      choosedIndex: e.currentTarget.dataset.index, 
      choosedData: e.currentTarget.dataset.itemvalue
    })

    // 特殊场景，需要多传几个数据
    if (this.data.chooseCategory == 'goodsProperty') {
      prevPage.setData({
        choosedPropertyId: that.data.optionsData.propertyId
      })
    }

    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})