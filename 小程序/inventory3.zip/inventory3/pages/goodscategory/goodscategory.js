// pages/goodscategory/goodscategory.js
import util from './../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodsCategory: '',
    goodsBrand: '',
    goodsModel: '',
    goodsProperties: '',
    goodsDesc: '',
  },

  goodsManageSubmit: function(e) {
    console.log(e.detail.value)
    var sessionId = util.getStorage('sessionId')
    // TODO 调用加入店铺接口
    var goodsManageSubmitResult = {
      "success": true,
      "msg": "成功",
      "data": {}
    }
    if (goodsManageSubmitResult.success == true) {
      wx.showModal({
        title: '提示',
        content: '恭喜！提交成功~',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateBack({
              delta: 1
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("这里可以获取到第二个页面选择的数据");
    console.log(this.data)

    if (this.data.choosedCategory == 'goodsCategory') {
      this.setData({
        goodsCategory: this.data.choosedData,
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})